from telebot import TeleBot
from config import WELCOME_MESSAGE, HELP_MESSAGE, ERROR_MESSAGE
from logger import logger
from PIL import Image, ImageDraw, ImageFont
import io

def format_price(price):
    formatted_price = "{:,}".format(int(price))
    return f"{formatted_price} IQD"

def apply_discount(price, discount=40):
    discounted_price = price * (1 - discount / 100)
    return int(discounted_price)

def register_handlers(bot: TeleBot):
    @bot.message_handler(commands=['start'])
    def start_command(message):
        try:
            logger.info(f"User {message.from_user.id} started the bot")
            bot.reply_to(message, WELCOME_MESSAGE)
        except Exception as e:
            logger.error(f"Error in start_command: {str(e)}")
            bot.reply_to(message, ERROR_MESSAGE)

    @bot.message_handler(commands=['help'])
    def help_command(message):
        try:
            logger.info(f"User {message.from_user.id} requested help")
            bot.reply_to(message, HELP_MESSAGE)
        except Exception as e:
            logger.error(f"Error in help_command: {str(e)}")
            bot.reply_to(message, ERROR_MESSAGE)

    @bot.message_handler(content_types=['photo'])
    def handle_photo(message):
        try:
            logger.info(f"User {message.from_user.id} sent a photo")
            file_info = bot.get_file(message.photo[-1].file_id)
            downloaded_file = bot.download_file(file_info.file_path)

            msg = bot.reply_to(message, "Write the price")
            bot.register_next_step_handler(msg, process_text_input, downloaded_file)

        except Exception as e:
            logger.error(f"Error in handle_photo: {str(e)}")
            bot.reply_to(message, ERROR_MESSAGE)

    def process_text_input(message, image_file):
        try:
            # Get the original price and calculate discount
            try:
                original_price = int(message.text.strip())
                discounted_price = apply_discount(original_price)
                formatted_price = format_price(discounted_price)
            except ValueError:
                bot.reply_to(message, "Please enter a valid number without commas or spaces")
                return

            # Open and prepare image
            image = Image.open(io.BytesIO(image_file))
            if image.mode != 'RGBA':
                image = image.convert('RGBA')

            # Create transparent overlay
            overlay = Image.new('RGBA', image.size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)

            # Calculate dynamic font size based on image dimensions and aspect ratio
            aspect_ratio = image.height / image.width
            if aspect_ratio > 1.5:  # Very tall images
                base_font_size = min(image.width // 20, image.height // 40)
            elif aspect_ratio > 1:  # Moderately tall images
                base_font_size = min(image.width // 18, image.height // 35)
            else:  # Landscape or square
                base_font_size = min(image.width, image.height) // 30

            font_size = max(30, min(base_font_size, 70))

            # Set up font
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
            except IOError:
                font = ImageFont.load_default()

            # Prepare text
            text = f"After Discount: {formatted_price}"
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]

            # Calculate dynamic padding based on image size and aspect ratio
            if aspect_ratio > 1.5:  # Very tall images
                min_padding = max(35, int(image.width * 0.08))
                max_padding = min(60, int(image.width * 0.15))
                horizontal_padding = int(image.width * 0.06)
            elif aspect_ratio > 1:  # Portrait image
                min_padding = max(35, int(image.width * 0.06))
                max_padding = min(60, int(image.width * 0.12))
                horizontal_padding = int(image.width * 0.05)
            else:  # Landscape or square
                min_padding = 35
                max_padding = 60
                horizontal_padding = min_padding

            padding = min(max_padding, max(min_padding, int(image.width * 0.04)))

            # Calculate box dimensions with extra space
            box_width = text_width + (horizontal_padding * 2)
            box_height = text_height + (padding * 2)

            # Ensure box isn't too wide relative to image width
            if aspect_ratio > 1.5:
                max_width = min(image.width * 0.95, 1200)
            elif aspect_ratio > 1:
                max_width = min(image.width * 0.9, 1200)
            else:
                max_width = min(image.width * 0.8, 1200)

            if box_width > max_width:
                box_width = max_width

            # Calculate position (centered horizontally, bottom with adjusted margin)
            x = (image.width - box_width) // 2

            if aspect_ratio > 1.5:
                bottom_margin = int(image.height * 0.12)
            elif aspect_ratio > 1:
                bottom_margin = int(image.height * 0.15)
            else:
                bottom_margin = padding

            y = image.height - box_height - bottom_margin

            # Draw semi-transparent black box with rounded corners
            radius = min(10, padding // 3)
            box_coords = [(x, y), (x + box_width, y + box_height)]

            # Create mask for rounded rectangle
            mask = Image.new('L', (int(box_width), int(box_height)), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.rounded_rectangle(((0, 0), (box_width-1, box_height-1)), radius=radius, fill=255)

            # Draw black box with transparency
            overlay_box = Image.new('RGBA', (int(box_width), int(box_height)), (0, 0, 0, 220))
            overlay.paste(overlay_box, (int(x), int(y)), mask)

            # Precisely center text in box
            text_x = x + (box_width - text_width) / 2
            text_y = y + (box_height - text_height) / 2
            draw.text((text_x, text_y), text, font=font, fill=(255, 255, 255, 255))

            # Composite and save
            result = Image.alpha_composite(image, overlay)
            output = io.BytesIO()
            result.save(output, format='PNG')
            output.seek(0)

            bot.send_photo(message.chat.id, output)
            logger.info(f"Processed and sent photo for user {message.from_user.id}")

        except Exception as e:
            logger.error(f"Error in process_text_input: {str(e)}")
            bot.reply_to(message, ERROR_MESSAGE)

    @bot.message_handler(func=lambda message: True)
    def echo_message(message):
        try:
            bot.reply_to(message, "Please send me a photo to add price information.")
        except Exception as e:
            logger.error(f"Error in echo_message: {str(e)}")
            bot.reply_to(message, ERROR_MESSAGE)