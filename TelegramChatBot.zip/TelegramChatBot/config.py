import os

# Bot configuration
API_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN')  # Get token from environment variables

# Bot messages
WELCOME_MESSAGE = "Welcome! Send me a photo and I'll add the price to it."
HELP_MESSAGE = """
Available commands:
/start - Start the bot
/help - Show this help message

Send me a photo, and I'll ask you for the price. 
I'll add it to the image in the format: Price: X,XXX,XXX IQD
"""
ERROR_MESSAGE = "Sorry, something went wrong. Please try again."