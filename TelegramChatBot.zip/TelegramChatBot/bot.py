import telebot
from telebot.handler_backends import State, StatesGroup
from config import API_TOKEN
from handlers import register_handlers
from logger import logger
import time

def main():
    # Add a small delay to ensure no other instances are running
    time.sleep(2)

    # Initialize bot
    try:
        if not API_TOKEN:
            logger.error("No API token provided. Please set the TELEGRAM_BOT_TOKEN environment variable.")
            return

        bot = telebot.TeleBot(API_TOKEN)
        logger.info("Bot initialized successfully")

        # Register message handlers
        register_handlers(bot)
        logger.info("Handlers registered successfully")

        # Start the bot
        logger.info("Bot starting...")
        bot.infinity_polling(timeout=10, long_polling_timeout=5)

    except Exception as e:
        logger.error(f"Critical error: {str(e)}")
        raise

if __name__ == '__main__':
    main()